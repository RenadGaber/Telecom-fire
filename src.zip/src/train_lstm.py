"""
train_lstm.py
----------------------------------
نموذج Deep Learning (LSTM) يعمل على نوافذ زمنية متسلسلة (Sequences)
لالتقاط أنماط التدهور التراكمية التي قد تفوتها نماذج الـ ML الكلاسيكية.

المدخل: نافذة من آخر SEQ_LEN قراءة لكل الحساسات
المخرج: احتمال حدوث خطر خلال أفق زمني قادم (Binary Classification)
"""

import numpy as np
import pandas as pd
import joblib
from sklearn.metrics import classification_report, roc_auc_score
import tensorflow as tf
from tensorflow.keras import layers, models, callbacks

SEQ_LEN = 32          # عدد القراءات السابقة المستخدمة (32 * 15min = 8 ساعات سياق)
TARGET = "target_early_warning"
BASE_SENSOR_COLS = [
    "temperature", "humidity", "power_load", "network_traffic", "smoke_level",
    "voltage_fluctuation", "vibration", "motor_temp", "voltage", "risk_score",
]


def create_sequences(df: pd.DataFrame, feature_cols, seq_len=SEQ_LEN):
    data = df[feature_cols].values
    target = df[TARGET].values
    X, y = [], []
    for i in range(seq_len, len(df)):
        X.append(data[i - seq_len:i])
        y.append(target[i])
    return np.array(X), np.array(y)


def build_lstm_model(seq_len, n_features):
    model = models.Sequential([
        layers.Input(shape=(seq_len, n_features)),
        layers.LSTM(64, return_sequences=True),
        layers.Dropout(0.3),
        layers.LSTM(32),
        layers.Dropout(0.3),
        layers.Dense(16, activation="relu"),
        layers.Dense(1, activation="sigmoid"),
    ])
    model.compile(
        optimizer=tf.keras.optimizers.Adam(learning_rate=1e-3),
        loss="binary_crossentropy",
        metrics=[tf.keras.metrics.AUC(name="auc"), "accuracy"],
    )
    return model


def run_lstm_pipeline(features_path="data/features_data.csv"):
    df = pd.read_csv(features_path, parse_dates=["timestamp"])
    feature_cols = [c for c in BASE_SENSOR_COLS if c in df.columns]

    split_idx = int(len(df) * 0.8)
    train_df, test_df = df.iloc[:split_idx], df.iloc[split_idx:]

    X_train, y_train = create_sequences(train_df, feature_cols)
    X_test, y_test = create_sequences(test_df, feature_cols)

    print(f"LSTM Train shape: {X_train.shape} | Test shape: {X_test.shape}")

    model = build_lstm_model(SEQ_LEN, len(feature_cols))

    # موازنة الفئات عبر class_weight بدل SMOTE (لأن SMOTE يكسر تسلسل الوقت)
    pos = y_train.sum()
    neg = len(y_train) - pos
    class_weight = {0: 1.0, 1: max(neg / max(pos, 1), 1.0)}

    early_stop = callbacks.EarlyStopping(monitor="val_auc", mode="max", patience=6, restore_best_weights=True)

    history = model.fit(
        X_train, y_train,
        validation_split=0.15,
        epochs=40,
        batch_size=64,
        class_weight=class_weight,
        callbacks=[early_stop],
        verbose=2,
    )

    proba = model.predict(X_test).flatten()
    preds = (proba >= 0.5).astype(int)

    print("\n📊 تقييم LSTM:")
    print(classification_report(y_test, preds, target_names=["Normal", "Risk/Early Warning"]))
    print(f"ROC-AUC: {roc_auc_score(y_test, proba):.4f}")

    model.save("models/lstm_model.keras")
    joblib.dump(feature_cols, "models/lstm_feature_cols.pkl")
    joblib.dump(SEQ_LEN, "models/lstm_seq_len.pkl")
    print("✅ تم حفظ نموذج LSTM في models/lstm_model.keras")

    return model, history


if __name__ == "__main__":
    run_lstm_pipeline()
