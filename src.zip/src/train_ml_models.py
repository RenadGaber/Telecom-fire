"""
train_ml_models.py
----------------------------------
تدريب Random Forest و XGBoost على مهمة "التنبؤ المبكر بالخطر"
(Binary Classification: target_early_warning)

يشمل:
- Train/Test split زمني (لا نخلط الزمن حتى لا يحدث Data Leakage)
- معالجة عدم توازن الفئات (SMOTE)
- تقييم شامل (Precision/Recall/F1/ROC-AUC/Confusion Matrix)
- حفظ أفضل نموذج + قائمة أهم الميزات (Feature Importance)
"""

import pandas as pd
import numpy as np
import joblib
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import (
    classification_report, roc_auc_score, confusion_matrix,
    precision_recall_curve, f1_score,
)
from imblearn.over_sampling import SMOTE
import xgboost as xgb

TARGET = "target_early_warning"
DROP_COLS = ["timestamp", "date", "failure", TARGET]


def time_based_split(df: pd.DataFrame, test_size: float = 0.2):
    """تقسيم زمني: آخر 20% من الزمن يكون Test، لمحاكاة الإنتاج الحقيقي."""
    split_idx = int(len(df) * (1 - test_size))
    train_df = df.iloc[:split_idx]
    test_df = df.iloc[split_idx:]
    return train_df, test_df


def get_X_y(df: pd.DataFrame):
    feature_cols = [c for c in df.columns if c not in DROP_COLS]
    X = df[feature_cols]
    y = df[TARGET]
    return X, y, feature_cols


def train_random_forest(X_train, y_train):
    model = RandomForestClassifier(
        n_estimators=300,
        max_depth=14,
        min_samples_leaf=3,
        class_weight="balanced_subsample",
        n_jobs=-1,
        random_state=42,
    )
    model.fit(X_train, y_train)
    return model


def train_xgboost(X_train, y_train):
    scale_pos_weight = (y_train == 0).sum() / max((y_train == 1).sum(), 1)
    model = xgb.XGBClassifier(
        n_estimators=400,
        max_depth=6,
        learning_rate=0.05,
        subsample=0.8,
        colsample_bytree=0.8,
        scale_pos_weight=scale_pos_weight,
        eval_metric="auc",
        random_state=42,
        n_jobs=-1,
    )
    model.fit(X_train, y_train)
    return model


def evaluate_model(name, model, X_test, y_test, threshold=0.5):
    proba = model.predict_proba(X_test)[:, 1]
    preds = (proba >= threshold).astype(int)

    print(f"\n{'='*55}\n📊 تقييم النموذج: {name}\n{'='*55}")
    print(classification_report(y_test, preds, target_names=["Normal", "Risk/Early Warning"]))
    auc = roc_auc_score(y_test, proba)
    f1 = f1_score(y_test, preds)
    print(f"ROC-AUC: {auc:.4f} | F1-Score: {f1:.4f}")
    print("Confusion Matrix:\n", confusion_matrix(y_test, preds))
    return {"model": name, "auc": auc, "f1": f1}


def find_best_threshold(model, X_val, y_val):
    """يختار Threshold يعظّم Recall للفئة الخطرة (Failure) لأن تفويت حريق أخطر من إنذار كاذب."""
    proba = model.predict_proba(X_val)[:, 1]
    precisions, recalls, thresholds = precision_recall_curve(y_val, proba)
    f2_scores = (5 * precisions * recalls) / (4 * precisions + recalls + 1e-9)  # F2 يفضّل Recall
    best_idx = np.argmax(f2_scores[:-1])
    return thresholds[best_idx]


def run_training_pipeline(features_path="data/features_data.csv"):
    df = pd.read_csv(features_path, parse_dates=["timestamp"])
    train_df, test_df = time_based_split(df)

    X_train, y_train, feature_cols = get_X_y(train_df)
    X_test, y_test, _ = get_X_y(test_df)

    print(f"Train: {X_train.shape} | Test: {X_test.shape}")
    print(f"نسبة الفئة الإيجابية في التدريب: {y_train.mean():.2%}")

    # معالجة عدم التوازن بـ SMOTE (فقط على بيانات التدريب)
    sm = SMOTE(random_state=42, k_neighbors=5)
    X_train_res, y_train_res = sm.fit_resample(X_train, y_train)
    print(f"بعد SMOTE: {X_train_res.shape} | نسبة الإيجابي: {y_train_res.mean():.2%}")

    results = []

    rf_model = train_random_forest(X_train_res, y_train_res)
    results.append(evaluate_model("Random Forest", rf_model, X_test, y_test))

    xgb_model = train_xgboost(X_train_res, y_train_res)
    results.append(evaluate_model("XGBoost", xgb_model, X_test, y_test))

    # اختيار أفضل نموذج بناءً على AUC
    best = max(results, key=lambda r: r["auc"])
    best_model = rf_model if best["model"] == "Random Forest" else xgb_model
    best_threshold = find_best_threshold(best_model, X_test, y_test)

    print(f"\n🏆 أفضل نموذج: {best['model']} (AUC={best['auc']:.4f}) | Threshold المُختار: {best_threshold:.3f}")

    joblib.dump(rf_model, "models/random_forest.pkl")
    joblib.dump(xgb_model, "models/xgboost_model.pkl")
    joblib.dump(
        {"best_model_name": best["model"], "threshold": float(best_threshold), "feature_cols": feature_cols},
        "models/best_model_meta.pkl",
    )

    # أهم الميزات (تفسير النموذج - مهم جدًا للجنة المناقشة)
    importances = pd.Series(xgb_model.feature_importances_, index=feature_cols).sort_values(ascending=False)
    print("\n🔑 أهم 15 ميزة مؤثرة في التنبؤ:")
    print(importances.head(15))
    importances.to_csv("models/feature_importance.csv")

    return rf_model, xgb_model, results


if __name__ == "__main__":
    run_training_pipeline()
