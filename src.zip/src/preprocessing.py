"""
preprocessing.py
----------------------------------
تنظيف ومعالجة بيانات الحساسات:
- تحويل التاريخ/الوقت
- معالجة القيم المفقودة (Interpolation)
- معالجة القيم الشاذة (IQR / physical bounds)
- إعادة ترتيب زمني وفرز
- Scaling (يُحفظ الـ Scaler لإعادة استخدامه في الإنتاج)
"""

import pandas as pd
import numpy as np
from sklearn.preprocessing import RobustScaler
import joblib

SENSOR_COLUMNS = [
    "temperature", "humidity", "power_load", "network_traffic", "smoke_level",
    "equipment_age_years", "voltage_fluctuation", "precipitation", "wind_speed",
    "vibration", "motor_temp", "voltage",
]

# حدود فيزيائية منطقية لكل حساس (لإزالة القراءات المستحيلة/الخاطئة من الجهاز)
PHYSICAL_BOUNDS = {
    "temperature": (-10, 150),
    "humidity": (0, 100),
    "power_load": (0, 200),
    "network_traffic": (0, 5000),
    "smoke_level": (0, 500),
    "vibration": (0, 20),
    "motor_temp": (0, 200),
    "voltage": (150, 280),
    "voltage_fluctuation": (0, 100),
}


def load_data(path: str) -> pd.DataFrame:
    df = pd.read_csv(path, parse_dates=["timestamp"])
    df = df.sort_values("timestamp").reset_index(drop=True)
    return df


def clip_physical_bounds(df: pd.DataFrame) -> pd.DataFrame:
    for col, (low, high) in PHYSICAL_BOUNDS.items():
        if col in df.columns:
            df[col] = df[col].clip(lower=low, upper=high)
    return df


def handle_missing_values(df: pd.DataFrame) -> pd.DataFrame:
    df = df.set_index("timestamp")
    numeric_cols = df.select_dtypes(include=[np.number]).columns
    # Interpolation زمني - أنسب لبيانات الحساسات المتسلسلة
    df[numeric_cols] = df[numeric_cols].interpolate(method="time").bfill().ffill()
    df = df.reset_index()
    return df


def remove_outliers_iqr(df: pd.DataFrame, cols=None, factor: float = 3.0) -> pd.DataFrame:
    """يستبدل القيم الشاذة المتطرفة (وليس حذفها حتى لا نفقد صفوف حرجة قرب الحوادث)."""
    cols = cols or SENSOR_COLUMNS
    for col in cols:
        if col not in df.columns:
            continue
        q1, q3 = df[col].quantile([0.25, 0.75])
        iqr = q3 - q1
        lower, upper = q1 - factor * iqr, q3 + factor * iqr
        df[col] = df[col].clip(lower=lower, upper=upper)
    return df


def scale_features(df: pd.DataFrame, cols=None, scaler_path="models/scaler.pkl", fit=True):
    cols = cols or SENSOR_COLUMNS
    cols = [c for c in cols if c in df.columns]
    if fit:
        scaler = RobustScaler()
        df[cols] = scaler.fit_transform(df[cols])
        joblib.dump(scaler, scaler_path)
    else:
        scaler = joblib.load(scaler_path)
        df[cols] = scaler.transform(df[cols])
    return df, cols


def preprocess_pipeline(raw_path: str, save_path: str = "data/processed_data.csv") -> pd.DataFrame:
    df = load_data(raw_path)
    df = clip_physical_bounds(df)
    df = handle_missing_values(df)
    df = remove_outliers_iqr(df)
    df.to_csv(save_path, index=False)
    print(f"✅ Preprocessing تم بنجاح | الشكل النهائي: {df.shape} -> {save_path}")
    return df


if __name__ == "__main__":
    preprocess_pipeline("data/central_sensors_data.csv")
