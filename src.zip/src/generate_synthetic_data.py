"""
generate_synthetic_data.py
----------------------------------
يولّد بيانات صناعية واقعية لمحاكاة قراءات حساسات سنترال اتصالات
(Temperature, Smoke, Power Load, Network Traffic, Vibration ...)
مع حقن أنماط "ما قبل الحريق/العطل" بشكل تدريجي قبل وقوع الحدث بساعات/أيام
حتى تتعلم النماذج نمط التدهور المبكر (Early Degradation Pattern).

Author: AI for Business - Graduation Project
"""

import numpy as np
import pandas as pd
from datetime import datetime, timedelta

np.random.seed(42)


def generate_synthetic_data(
    n_days: int = 180,
    freq_minutes: int = 15,
    n_incidents: int = 25,
    out_path: str = "data/central_sensors_data.csv",
) -> pd.DataFrame:
    """يولد داتا سلاسل زمنية لعدة محطات (centrals) مع حوادث حريق/عطل مزروعة."""

    start = datetime(2025, 1, 1)
    periods = int((n_days * 24 * 60) / freq_minutes)
    timestamps = [start + timedelta(minutes=freq_minutes * i) for i in range(periods)]
    n = len(timestamps)

    # ---- خط أساس طبيعي (Normal Operating Baseline) ----
    temperature = np.random.normal(28, 2.5, n)
    humidity = np.random.normal(55, 8, n)
    power_load = np.random.normal(65, 10, n)          # % حمل الكهرباء
    network_traffic = np.random.normal(500, 120, n)   # Mbps
    smoke_level = np.random.normal(5, 1.5, n)          # ppm
    equipment_age_years = np.random.uniform(1, 15, n)
    voltage_fluctuation = np.random.normal(2, 0.8, n)  # %
    precipitation = np.clip(np.random.exponential(0.5, n), 0, 40)
    wind_speed = np.random.normal(12, 4, n)
    vibration = np.random.normal(0.3, 0.1, n)          # mm/s
    motor_temp = np.random.normal(45, 5, n)
    voltage = np.random.normal(220, 4, n)

    # موسمية يومية (الحرارة أعلى ظهرًا، الشبكة أعلى في المساء)
    hours = np.array([t.hour for t in timestamps])
    temperature += 4 * np.sin((hours - 6) / 24 * 2 * np.pi)
    network_traffic += 250 * np.sin((hours - 14) / 24 * 2 * np.pi).clip(min=0)

    failure = np.zeros(n, dtype=int)

    # ---- زرع حوادث حريق/عطل تدريجية قبل وقوعها ----
    incident_indices = np.random.choice(
        range(n // 10, n - 200), size=n_incidents, replace=False
    )

    for idx in incident_indices:
        # مدة "التدهور" قبل الحادثة: بين 6 ساعات إلى 3 أيام (بوحدة السجلات)
        degrade_steps = np.random.randint(24, 288)  # 6h -> 3 days (15min steps)
        start_idx = max(0, idx - degrade_steps)

        ramp = np.linspace(0, 1, idx - start_idx) ** 2  # تصاعد غير خطي (تسارع قرب الحدث)

        temperature[start_idx:idx] += ramp * np.random.uniform(15, 30)
        smoke_level[start_idx:idx] += ramp * np.random.uniform(40, 90)
        power_load[start_idx:idx] += ramp * np.random.uniform(20, 35)
        voltage_fluctuation[start_idx:idx] += ramp * np.random.uniform(8, 15)
        vibration[start_idx:idx] += ramp * np.random.uniform(1.5, 3)
        motor_temp[start_idx:idx] += ramp * np.random.uniform(25, 45)
        network_traffic[start_idx:idx] *= (1 + ramp * np.random.uniform(0.3, 0.8))

        # نقطة الحدث نفسها وبعدها بقليل تُعتبر Failure = 1
        event_window = slice(idx, min(idx + 4, n))
        failure[event_window] = 1
        temperature[event_window] += np.random.uniform(30, 50)
        smoke_level[event_window] += np.random.uniform(80, 150)

    df = pd.DataFrame(
        {
            "timestamp": timestamps,
            "temperature": temperature.round(2),
            "humidity": np.clip(humidity, 10, 100).round(2),
            "power_load": np.clip(power_load, 0, 150).round(2),
            "network_traffic": np.clip(network_traffic, 0, None).round(2),
            "smoke_level": np.clip(smoke_level, 0, None).round(2),
            "equipment_age_years": equipment_age_years.round(2),
            "voltage_fluctuation": np.clip(voltage_fluctuation, 0, None).round(2),
            "failure": failure,
            "precipitation": precipitation.round(2),
            "wind_speed": np.clip(wind_speed, 0, None).round(2),
            "vibration": np.clip(vibration, 0, None).round(3),
            "motor_temp": motor_temp.round(2),
            "voltage": voltage.round(2),
        }
    )

    df["date"] = df["timestamp"].dt.date
    daily_temp = df.groupby("date")["temperature"].transform("mean")
    daily_hum = df.groupby("date")["humidity"].transform("mean")
    df["temp_mean"] = daily_temp.round(2)
    df["humidity_mean"] = daily_hum.round(2)

    df = df[
        [
            "timestamp", "temperature", "humidity", "power_load", "network_traffic",
            "smoke_level", "equipment_age_years", "voltage_fluctuation", "failure",
            "date", "temp_mean", "humidity_mean", "precipitation", "wind_speed",
            "vibration", "motor_temp", "voltage",
        ]
    ]

    df.to_csv(out_path, index=False)
    print(f"✅ تم توليد {len(df):,} سجل | عدد حوادث الفشل: {df['failure'].sum()} -> {out_path}")
    return df


if __name__ == "__main__":
    generate_synthetic_data()
