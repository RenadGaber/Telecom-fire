"""
alert_system.py
----------------------------------
نظام تنبيه مبكر (Early Warning System):
- يراقب مخرجات النموذج (Risk Probability) لحظيًا
- عند تجاوز الاحتمال لحد "متوسط" -> إشعار Warning
- عند تجاوزه لحد "حرج" -> إرسال Email Alert فوري + سجل الحادثة

يستخدم SMTP (يعمل مع Gmail عبر App Password أو أي مزود SMTP آخر).
القيم الحساسة (كلمة المرور) تُقرأ من متغيرات البيئة (.env) وليس مكتوبة بالكود.
"""

import smtplib
import ssl
import os
import json
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime
from dotenv import load_dotenv

load_dotenv()

SMTP_SERVER = os.getenv("SMTP_SERVER", "smtp.gmail.com")
SMTP_PORT = int(os.getenv("SMTP_PORT", 465))
SENDER_EMAIL = os.getenv("SENDER_EMAIL", "")
SENDER_PASSWORD = os.getenv("SENDER_APP_PASSWORD", "")
RECEIVER_EMAILS = os.getenv("RECEIVER_EMAILS", "").split(",")

WARNING_THRESHOLD = 0.5   # احتمال متوسط -> تنبيه داخل الداشبورد فقط
CRITICAL_THRESHOLD = 0.75  # احتمال عالٍ -> إيميل فوري

LOG_PATH = "data/alerts_log.json"


def classify_risk_level(probability: float) -> str:
    if probability >= CRITICAL_THRESHOLD:
        return "CRITICAL"
    elif probability >= WARNING_THRESHOLD:
        return "WARNING"
    return "NORMAL"


def build_email_body(central_name, probability, sensor_snapshot: dict, risk_level):
    rows = "".join(
        f"<tr><td style='padding:4px 10px;border:1px solid #ddd'>{k}</td>"
        f"<td style='padding:4px 10px;border:1px solid #ddd'>{v}</td></tr>"
        for k, v in sensor_snapshot.items()
    )
    color = "#d32f2f" if risk_level == "CRITICAL" else "#f9a825"
    html = f"""
    <html><body style="font-family:Arial,sans-serif">
      <h2 style="color:{color}">🚨 تنبيه {risk_level}: احتمال خطر مرتفع في {central_name}</h2>
      <p><b>احتمالية الخطر المتوقعة:</b> {probability:.1%}</p>
      <p><b>وقت الرصد:</b> {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
      <h3>قراءات الحساسات الحالية:</h3>
      <table style="border-collapse:collapse">{rows}</table>
      <p style="margin-top:15px;color:#555">
        يُرجى إرسال فريق الصيانة الطارئ للفحص الفوري وفقًا لبروتوكول السلامة.
      </p>
    </body></html>
    """
    return html


def send_email_alert(central_name: str, probability: float, sensor_snapshot: dict):
    risk_level = classify_risk_level(probability)
    if risk_level != "CRITICAL":
        return False, risk_level

    if not SENDER_EMAIL or not SENDER_PASSWORD or not RECEIVER_EMAILS[0]:
        print("⚠️ إعدادات البريد غير مكتملة (.env) - تم تخطي الإرسال الفعلي (وضع Demo).")
        _log_alert(central_name, probability, risk_level, sent=False)
        return False, risk_level

    msg = MIMEMultipart("alternative")
    msg["Subject"] = f"🚨 [عاجل] احتمال حريق/عطل مرتفع - {central_name}"
    msg["From"] = SENDER_EMAIL
    msg["To"] = ", ".join(RECEIVER_EMAILS)
    msg.attach(MIMEText(build_email_body(central_name, probability, sensor_snapshot, risk_level), "html"))

    try:
        context = ssl.create_default_context()
        with smtplib.SMTP_SSL(SMTP_SERVER, SMTP_PORT, context=context) as server:
            server.login(SENDER_EMAIL, SENDER_PASSWORD)
            server.sendmail(SENDER_EMAIL, RECEIVER_EMAILS, msg.as_string())
        print(f"✅ تم إرسال إنذار Email بنجاح إلى {RECEIVER_EMAILS}")
        _log_alert(central_name, probability, risk_level, sent=True)
        return True, risk_level
    except Exception as e:
        print(f"❌ فشل إرسال الإيميل: {e}")
        _log_alert(central_name, probability, risk_level, sent=False, error=str(e))
        return False, risk_level


def _log_alert(central_name, probability, risk_level, sent, error=None):
    entry = {
        "timestamp": datetime.now().isoformat(),
        "central": central_name,
        "probability": round(float(probability), 4),
        "risk_level": risk_level,
        "email_sent": sent,
        "error": error,
    }
    logs = []
    if os.path.exists(LOG_PATH):
        try:
            with open(LOG_PATH, "r", encoding="utf-8") as f:
                logs = json.load(f)
        except json.JSONDecodeError:
            logs = []
    logs.append(entry)
    os.makedirs(os.path.dirname(LOG_PATH), exist_ok=True)
    with open(LOG_PATH, "w", encoding="utf-8") as f:
        json.dump(logs, f, ensure_ascii=False, indent=2)


if __name__ == "__main__":
    # اختبار سريع (Demo mode - بدون إرسال فعلي إن لم يوجد .env)
    demo_snapshot = {
        "temperature": "68.4 °C", "smoke_level": "112 ppm",
        "power_load": "94%", "voltage_fluctuation": "13.2%",
    }
    send_email_alert("Central - Ramses", 0.82, demo_snapshot)
