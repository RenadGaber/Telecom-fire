"""
feature_engineering.py
----------------------------------
يبني ميزات متقدمة تلتقط "نمط التدهور" قبل وقوع الحريق/العطل:
- Rolling statistics (mean/std/min/max) على نوافذ زمنية متعددة
- Rate of Change (المشتقة الزمنية) لكل حساس
- Lag features
- Composite Risk Score (مؤشر خطر مركب فيزيائي)
- Time-based features (hour, dayofweek)
- Target Horizon Shifting: تحويل المشكلة لتنبؤ "هل سيحدث عطل خلال H ساعة قادمة؟"
"""

import pandas as pd
import numpy as np

SENSOR_COLUMNS = [
    "temperature", "humidity", "power_load", "network_traffic", "smoke_level",
    "voltage_fluctuation", "vibration", "motor_temp", "voltage",
]

ROLLING_WINDOWS = [4, 16, 96]   # بافتراض بيانات كل 15 دقيقة -> 1h, 4h, 24h


def add_rolling_features(df: pd.DataFrame) -> pd.DataFrame:
    for col in SENSOR_COLUMNS:
        if col not in df.columns:
            continue
        for w in ROLLING_WINDOWS:
            df[f"{col}_roll_mean_{w}"] = df[col].rolling(w, min_periods=1).mean()
            df[f"{col}_roll_std_{w}"] = df[col].rolling(w, min_periods=1).std().fillna(0)
            df[f"{col}_roll_max_{w}"] = df[col].rolling(w, min_periods=1).max()
    return df


def add_rate_of_change(df: pd.DataFrame) -> pd.DataFrame:
    for col in SENSOR_COLUMNS:
        if col not in df.columns:
            continue
        df[f"{col}_diff_1"] = df[col].diff().fillna(0)
        df[f"{col}_pct_change"] = df[col].pct_change().replace([np.inf, -np.inf], 0).fillna(0)
    return df


def add_lag_features(df: pd.DataFrame, lags=(1, 4, 16)) -> pd.DataFrame:
    for col in SENSOR_COLUMNS:
        if col not in df.columns:
            continue
        for lag in lags:
            df[f"{col}_lag_{lag}"] = df[col].shift(lag).bfill()
    return df


def add_time_features(df: pd.DataFrame) -> pd.DataFrame:
    df["hour"] = df["timestamp"].dt.hour
    df["dayofweek"] = df["timestamp"].dt.dayofweek
    df["hour_sin"] = np.sin(2 * np.pi * df["hour"] / 24)
    df["hour_cos"] = np.cos(2 * np.pi * df["hour"] / 24)
    return df


def add_composite_risk_score(df: pd.DataFrame) -> pd.DataFrame:
    """مؤشر خطر مركب مبني على معرفة هندسية: الدخان والحرارة وارتفاع الحمل أهم إشارات."""
    def norm(s):
        rng = (s.max() - s.min())
        return (s - s.min()) / rng if rng > 0 else s * 0

    df["risk_score"] = (
        0.30 * norm(df["smoke_level"]) +
        0.25 * norm(df["temperature"]) +
        0.20 * norm(df["power_load"]) +
        0.15 * norm(df["voltage_fluctuation"]) +
        0.10 * norm(df["vibration"])
    ) * 100
    return df


def create_future_horizon_target(df: pd.DataFrame, horizon_steps: int = 16, label_col="failure") -> pd.DataFrame:
    """
    يحول الهدف من "هل يوجد عطل الآن" إلى "هل سيحدث عطل خلال H خطوة قادمة؟"
    (Early Warning target) — horizon_steps=16 بمعدل 15 دقيقة = تحذير قبل 4 ساعات.
    """
    future_window = df[label_col].shift(-horizon_steps).rolling(horizon_steps, min_periods=1).max()
    df["target_early_warning"] = df[[label_col]].join(
        df[label_col].iloc[::-1].rolling(horizon_steps, min_periods=1).max().iloc[::-1].rename("fwd_max")
    )["fwd_max"].fillna(0).astype(int)
    return df


def build_features(df: pd.DataFrame, horizon_steps: int = 16) -> pd.DataFrame:
    df = df.copy()
    df = add_time_features(df)
    df = add_rolling_features(df).copy()
    df = add_rate_of_change(df).copy()
    df = add_lag_features(df).copy()
    df = add_composite_risk_score(df)
    df = create_future_horizon_target(df, horizon_steps=horizon_steps)
    df = df.dropna().reset_index(drop=True)
    return df


if __name__ == "__main__":
    df = pd.read_csv("data/processed_data.csv", parse_dates=["timestamp"])
    df = build_features(df)
    df.to_csv("data/features_data.csv", index=False)
    print(f"✅ Feature Engineering تم | الشكل: {df.shape}")
    print(f"عدد أعمدة الميزات: {df.shape[1]} | نسبة التحذير المبكر الإيجابي: {df['target_early_warning'].mean():.2%}")
